-- Crime Spree Mods Compatibility
-- Loads patches only for mods that are actually installed.

local mod_path = ModPath

local function load_patch(filename)
    local path = mod_path .. "lua/compat/" .. filename
    local ok, err = pcall(dofile, path)
    if not ok then
        log("[CSMC] Failed to load patch " .. filename .. ": " .. tostring(err))
    end
end

if BLT and BLT.Mods then
    if BLT.Mods:GetModByName("Extra Heist Info") then
        load_patch("ehi.lua")
    end
    if BLT.Mods:GetModByName("Full Speed Swarm") then
        load_patch("fss.lua")
    end
end
