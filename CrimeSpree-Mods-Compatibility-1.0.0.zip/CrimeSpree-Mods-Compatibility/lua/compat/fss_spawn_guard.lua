-- Patch: Full Speed Swarm — Crime Spree compatibility (Part 2: produce guard)
-- Hooked on lib/managers/missionmanager — ElementSpawnEnemyDummy is defined here.
--
-- Even with safe_spawn_unit returning nil for unloaded units,
-- vanilla produce() crashes because it calls unit:brain() without a nil check.
-- This override wraps produce() in pcall and on_executed() to handle nil gracefully.

if not (BLT and BLT.Mods and BLT.Mods:GetModByName("Full Speed Swarm")) then
    return
end

if not ElementSpawnEnemyDummy then
    return
end

-- Override on_executed: wrap produce() in pcall to catch nil unit crash
local _original_on_executed = ElementSpawnEnemyDummy.on_executed

function ElementSpawnEnemyDummy:on_executed(instigator)
    if not self._values.enabled then
        return
    end

    if not managers.groupai:state():is_AI_enabled() and not Application:editor() then
        return
    end

    local ok, unit = pcall(self.produce, self)

    if not ok then
        log("[CSMC/FSS] produce() error caught: " .. tostring(unit))
        return
    end

    if not unit then
        log("[CSMC/FSS] produce() returned nil — spawn skipped")
        return
    end

    ElementSpawnEnemyDummy.super.on_executed(self, unit)
end
