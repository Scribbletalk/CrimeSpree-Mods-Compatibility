-- Patch: Extra Heist Info — Crime Spree crash fix
-- Loaded at lib/setups/setup so Setup.init_finalize exists when we register the hook.
-- Root cause: EHIAssaultManager callback does tweak_data.group_ai[GetGroupAIState()].assault
-- without nil check. In Crime Spree, GetGroupAIState() returns a CS-specific key that
-- propagates as a Lua error to the C++ boundary, causing an access violation crash.
-- Fix: wrap CallAssaultTypeChangedCallback dispatch in pcall.

if not (BLT and BLT.Mods and BLT.Mods:GetModByName("Extra Heist Info")) then
    return
end

Hooks:PostHook(Setup, "init_finalize", "CSMC_EHI_AssaultCallbackFix", function()
    if not managers.ehi_assault then
        return
    end

    local original_call = managers.ehi_assault.CallAssaultTypeChangedCallback

    managers.ehi_assault.CallAssaultTypeChangedCallback = function(self, mode, element_id)
        local ok, err = pcall(original_call, self, mode, element_id)
        if not ok then
            local in_cs = managers.crime_spree and managers.crime_spree:is_active()
            if in_cs then
                log("[CSMC-EHI] Suppressed CS crash in CallAssaultTypeChangedCallback: " .. tostring(err))
            end
        end
    end
end)
