-- Patch: Full Speed Swarm — Crime Spree compatibility (Part 1: safe_spawn_unit)
-- Hooked on lib/setups/setup — early enough to wrap safe_spawn_unit before missions.
--
-- Defensive fix: make safe_spawn_unit check if the unit resource is loaded
-- before calling World:spawn_unit(). Vanilla skips the check in non-editor
-- mode, which can cause crashes with FSS's accelerated spawning.

if not (BLT and BLT.Mods and BLT.Mods:GetModByName("Full Speed Swarm")) then
    return
end

if not safe_spawn_unit then
    return
end

local _original_safe_spawn_unit = safe_spawn_unit

function safe_spawn_unit(unit_name, ...)
    if not unit_name then
        return _original_safe_spawn_unit(unit_name, ...)
    end

    local ok, unit_ids = pcall(function() return unit_name:id() end)
    if not ok or not unit_ids then
        return _original_safe_spawn_unit(unit_name, ...)
    end

    if not PackageManager:has(Idstring("unit"), unit_ids) then
        local name_str = tostring(unit_name) or "unknown"
        log("[CSMC/FSS] Blocked spawn of unloaded unit: " .. name_str)

        DelayedCalls:Add("CSR_Compat_FSS_ChatWarn_" .. tostring(math.random(100000)), 0.5, function()
            if managers.chat then
                managers.chat:_receive_message(
                    1,
                    "[CSMC]",
                    "Blocked crash: unit not loaded (" .. name_str .. ")",
                    tweak_data.system_chat_color
                )
            end
        end)

        return nil
    end

    return _original_safe_spawn_unit(unit_name, ...)
end
